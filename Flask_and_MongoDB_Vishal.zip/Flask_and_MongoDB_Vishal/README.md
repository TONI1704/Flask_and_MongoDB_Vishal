Flask & MongoDB Assignment

 Objective
A Flask application with a JSON API (/api) that reads data.json, and a frontend form that saves submitted name, email and message fields to MongoDB Atlas.

 Project structure

Flask_and_MongoDB_Vishal
 app.py
 data.json
 requirements.txt
 .env
 .env.example
 README.md
 Documentation.docx
 templates/
     index.html
     success.html


Important:Keep data.json beside app.py in the main project folder, not inside venv. Do not include venv/ or .env in your submission ZIP or public GitHub repository.

Setup (Windows PowerShell)

python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py


Create .env beside app.py:

MONGO_URI=mongodb+srv://vishalmunshi56_db_user:UzinTSamCtO0OMJ2@cluster0.qcbv2oy.mongodb.net/

Replace the placeholders with your Atlas connection string. Never publish your real .env file or database password.

Open:
- Form: http://127.0.0.1:5000/
- JSON API: http://127.0.0.1:5000/api


Application behaviour
1. /api reads data.json and returns its contents as a JSON list.
2. The frontend form collects name, email and message.
3. Flask inserts submitted data into MongoDB Atlas.
4. On success, the app redirects to a page displaying Data submitted successfully.
5. On error, the form page should display an error without redirecting.

The project configuration shown during development uses database flask_assignment and collection submissions. Confirm these names in your final app.py.

 Evidence to add

 - Add screenshots to Documentation.docx showing:
- VS Code project structure.
- Terminal with python app.py running.
- Browser output from /api.
- Successful form submission page.
- MongoDB Atlas submissions collection.
- Error handling, if tested.

 GitHub and ZIP

Add .env and venv/ to .gitignore. Commit .env.example, never .env. Add your GitHub repository URL to the documentation. Compress the complete project folder into one ZIP file, excluding venv/ and .env.

 Author

- Student: VISHAL MUNSHI
- Assignment: Flask & MongoDB – DevOps

