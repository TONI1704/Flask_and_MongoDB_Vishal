from flask import Flask, render_template, request, redirect, url_for,jsonify
from pymongo import MongoClient
from dotenv import load_dotenv
import os
import json

# Project Configration

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Load .env file
load_dotenv(os.path.join(BASE_DIR, ".env"))

app = Flask(__name__)

# MongoDB connection
MONGO_URI = os.getenv("MONGO_URI")

client = None
db = None
collection = None

if MONGO_URI:
    client = MongoClient(
        MONGO_URI,
        serverSelectionTimeoutMS=5000
    )

    db = client["flask_assignment"]
    collection = db["submissions"]


#  JSON API Route


@app.route("/api")
def api():

    try:
        file_path = os.path.join(BASE_DIR, "data.json")

        with open(file_path, "r", encoding="utf-8") as file:
            data = json.load(file)

        return jsonify(data), 200

    except FileNotFoundError:
        return jsonify({
            "error": "data.json file not found"
        }), 404

    except json.JSONDecodeError:
        return jsonify({
            "error": "Invalid JSON format"
        }), 500

    except Exception as e:
        print("JSON ERROR:", e)

        return jsonify({
            "error": "Unable to read JSON data"
        }), 500


# Frontend Form

@app.route("/", methods=["GET", "POST"])
def home():

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        message = request.form.get("message", "").strip()

        # Validate form
        if not name or not email or not message:

            return render_template(
                "index.html",
                error="All fields are required.")

        
        if collection is None:

            return render_template(
                "index.html",
                error="MongoDB is not configured. Check your .env file.")

        try:
            
            client.admin.command("ping")

           
            collection.insert_one({
                "name": name,
                "email": email,
                "message": message
            })

            # Redirect to success page
            return redirect(url_for("success"))

        except Exception as e:

            print("MONGODB ERROR:", e)

            return render_template(
                "index.html",
                error="Database connection failed. Please try again."
            )

    return render_template("index.html")


# Success Page

@app.route("/success")
def success():

    return render_template("success.html")


# Run Flask Application

if __name__ == "__main__":

    app.run(debug=True,host="127.0.0.1",port=5000)